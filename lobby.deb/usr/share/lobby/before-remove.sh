#!/bin/bash

rm -r /usr/share/lobby/*
